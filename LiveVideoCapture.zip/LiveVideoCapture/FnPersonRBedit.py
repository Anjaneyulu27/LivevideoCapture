from random import randint
import time

class MyPerson:
    tracks = []
    def __init__(self, i, xi, yi, max_age):
        self.i = i
        self.x = xi
        self.y = yi
        self.tracks = []
        self.R = randint(0,255)
        self.G = randint(0,255)
        self.B = randint(0,255)
        self.done = False
        self.state = '0'
        self.age = 0
        self.max_age = max_age
        self.dir = None
    def getRGB(self):
        return (self.R,self.G,self.B)
    def getTracks(self):
        return self.tracks
    def getId(self):
        return self.i
    def getState(self):
        return self.state
    def getDir(self):
        return self.dir
    def getX(self):
        return self.x
    def getY(self):
        return self.y
    def updateCoords(self, xn, yn):
        self.age = 0
        self.tracks.append([self.x,self.y])
        print ("track",self.tracks)
        self.x = xn
        self.y = yn
    def setDone(self):
        self.done = True
    def timedOut(self):
        return self.done
    
    def going_RIGHT_blue(self,left,right):
        if len(self.tracks) >= 2:
            #print("diji not moving right: left",left,"track 1",self.tracks[-1][0],"track2",self.tracks[-2][0])            
            if self.state == '0':
                if self.tracks[-1][0] > left and self.tracks[-2][0] <= left: # cross the line
                    print("going right")
                    self.state = '1'                    
                    return True
            else:
                return False
        else:
            return False
    def going_RIGHT_Extreme(self,right):
        #print("Fn in R extreme loop")
        if len(self.tracks) >= 2:        
            if self.state == '1':
                if self.tracks[-1][0] > right and self.tracks[-2][0] <= right: # cross the line
                    self.dir = 'right'
                    print("gone right")
                    self.state = '0'
                    return True
            else:
                return False
        else:
            return False
    def going_LEFT_red(self,left,right):
        if len(self.tracks) >= 2:        
            if self.state == '0' :
                if self.tracks[-1][0] < right and self.tracks[-2][0] >= right: # cross the line
                    self.state = '2'                    
                    return True
            else:
                return False
        else:
            return False
    def going_LEFT_Extreme(self,left):
        if len(self.tracks) >= 2:        
            if self.state == '2' :
                if self.tracks[-1][0] < left and self.tracks[-2][0] >= left: # cross the line
                    self.dir = 'left'
                    self.state = '0'
                    return True
            else:
                return False
        else:
            return False
    def age_one(self):
        self.age += 1
        if self.age > self.max_age:
            self.done = True
        return True
class MultiPerson:
    def __init__(self, persons, xi, yi):
        self.persons = persons
        self.x = xi
        self.y = yi
        self.tracks = []
        self.R = randint(0,255)
        self.G = randint(0,255)
        self.B = randint(0,255)
        self.done = False
