import cv2
import FnPersonRBedit
from cam import Cam

class VideoCamera(object):
    def __init__(self):
        self.cam = Cam()

    def __del__(self):
        self.cam.cap.release()

    def get_frame(self):
        while(self.cam.cap.isOpened()):
            ret, frame = self.cam.cap.read()
            frame = cv2.flip(frame,1)
            for person in self.cam.persons:
                person.age_one() # age every person one frame

            try:
                mask = self.cam.imageProcessing(frame)
            except:
                print('EOF')
                print('Right:',self.cam.cnt_right)
                print('Left:',self.cam.cnt_left)
                break

            # RETR_EXTERNAL returns only extreme outer flags. All child contours are left behind.
            _, contours0, hierarchy = cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
            for cnt in contours0:
                area = cv2.contourArea(cnt)
                if area > self.cam.areaTH:
                    self.cx,cy,w,h = self.cam.detectMovingObject(cnt,frame)
                    new = True  # initialising obj identified is a new person
                    if self.cx in range(self.cam.left_limit,self.cam.right_limit):
                        for person in self.cam.persons:
                            new,cnt = self.cam.calcCoordinates(self.cx,cy,w,h,person,new)
                            if cnt == 0:
                                self.cam.cnt_left += 1
                                print("in/left count: ", self.cam.cnt_left)
                            elif cnt == 1:
                                self.cam.cnt_right += 1
                                print("out/right count: ", self.cam.cnt_right)
                        if new == True:
                            print("new")
                            p = FnPersonRBedit.MyPerson(self.cam.pid,self.cx,cy, self.cam.max_p_age)
                            self.cam.persons.append(p)
                            self.cam.pid += 1

            for person in self.cam.persons:
                self.cam.drawTrackPath(self.cx,frame,person)

            jpeg = self.cam.displayframe(self.cam.cnt_left,self.cam.cnt_right,frame)
            k = cv2.waitKey(30) & 0xff
            if k == 27:
                break
            #ret, jpeg = cv2.imencode('.jpg', frame)
            return jpeg

    def get_framenum(self):
        ret, frame = self.cam.cap.read()
        frame = cv2.flip(frame, 2)
        incam, outcam = self.cam.displayframe(self.cam.cnt_left, self.cam.cnt_right, frame)
        return incam, outcam


    def destroyWindows(self):
        cv2.destroyAllWindows()