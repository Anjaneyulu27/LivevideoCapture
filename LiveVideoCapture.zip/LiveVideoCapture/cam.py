import numpy as np
import cv2
import FnPersonRBedit
import time
class Cam(object):
    def __init__(self):
        self.width = 800
        self.height = 600

        # dividing screen to get x-coordinates of red and blue line
        self.right = int(6.5 * (self.width / 10))
        self.left = int(3.5 * (self.width / 10))

        # extreme lines x-coordinates
        self.left_limit = int(2 * (self.width / 10))
        self.right_limit = int(8 * (self.width / 10))

        # threshold value to detect an object
        self.areaTH = int(self.width * self.height / 100)

        # count variables
        self.cnt_left = 0
        self.cnt_right = 0

        self.persons = []
        self.max_p_age = 5
        self.pid = 1

        # morphology
        self.fgbg = cv2.createBackgroundSubtractorMOG2(detectShadows=True)
        self.kernelOp = np.ones((3, 3), np.uint8)
        self.kernelCl = np.ones((11, 11), np.uint8)

        # camera opening
        self.cap = cv2.VideoCapture(0)


    # cap = PiCamera()
    # cap.resolution = (width, height)
    # cap.framerate = 15
    # cap.vflip = True # flipping video vertically
    # cap.hflip = True # flipping video horizontally
    # rawCapture = PiRGBArray(cap)

    # time.sleep(0.1)

    def imageProcessing(self, frame):
        # Applying background subtraction
        fgmask = self.fgbg.apply(frame)
        ret, imBin = cv2.threshold(fgmask, 200, 255, cv2.THRESH_BINARY)

        # Opening (erode->dilate)
        mask = cv2.morphologyEx(imBin, cv2.MORPH_OPEN, self.kernelOp)

        # Closing (dilate -> erode)
        mask2 = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, self.kernelCl)

        return mask2


    def detectMovingObject(self, cnt, frame):
        # draw rectangle bounding obj
        x, y, w, h = cv2.boundingRect(cnt)
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

        # Finding centroid of the contour
        M = cv2.moments(cnt)
        cx = int(M['m10'] / M['m00'])
        cy = int(M['m01'] / M['m00'])
        cv2.circle(frame, (cx, cy), 5, (0, 0, 255), -1)
        return cx, cy, w, h


    def directionCheck(self, person, cnt):
        # if direction right set cnt
        if person.going_RIGHT_blue(self.left, self.right) == True:
            print("going right")
        if person.going_LEFT_red(self.left, self.right) == True:
            print("going left")
        if person.going_RIGHT_Extreme(self.right) == True:
            cnt = 1
        # if direction left reset cnt
        elif person.going_LEFT_Extreme(self.left) == True:
            cnt = 0
        return cnt


    def checkInActiveRegion(self, cx, cy, person):
        if person.getState() == '1':
            if person.getDir() == 'left' and cx > self.left_limit:
                person.setDone()
            elif person.getDir() == 'right' and cx < self.right_limit:
                person.setDone()
        if cx < self.left_limit or cx > self.right_limit:
            # if obj outside active region remove person from the persons list
            index = self.persons.index(person)
            self.persons.pop(index)
            del person  # free allocated memory


    def calcCoordinates(self, cx, cy, w, h, person, new):
        cnt = 2  # initialising cnt to 2
        if abs(cx - person.getX()) <= w and abs(
                        cy - person.getY()) <= h:  # if the dist btw prev & currnt pt is less than width & height of current person then it is the same person
            new = False  # false => initialising it as not a new person
            person.updateCoords(cx, cy)  # update coordinates in the objct and resets age
            cnt = self.directionCheck(person, cnt)
        self.checkInActiveRegion(cx, cy, person)
        return new, cnt


    def drawTrackPath(self, cx, frame, person):
        if len(person.getTracks()) >= 2 and cx in range(self.left_limit, self.right_limit):
            pts = np.array(person.getTracks(), np.int32)
            pts = pts.reshape((-1, 1, 2))
            # frame = cv2.polylines(frame,[pts],False,person.getRGB())
        cv2.putText(frame, str(person.getId()), (person.getX(), person.getY()), cv2.FONT_HERSHEY_SIMPLEX, 0.3,
                    person.getRGB(), 1, cv2.LINE_AA)


    def displayframe(self, cnt_left, cnt_right, frame):
        str_left = 'IN: ' + str(cnt_left)
        str_right = 'OUT: ' + str(cnt_right)

        cv2.line(frame, (self.left, 0), (self.left, self.height), (255, 0, 0), 3)  # left blue line
        cv2.line(frame, (self.right, 0), (self.right, self.height), (0, 0, 255), 3)  # right red line
        # cv2.line(frame, (left_limit, 0), (left_limit, height), (255, 255, 255), 1) # extreme end left line
        # cv2.line(frame, (right_limit, 0), (right_limit, height), (255, 255, 255), 1) #extreme end right line

        # displaying count on the screen
        #cv2.putText(frame, str_left, (10, 90), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (255, 0, 0), 3, cv2.LINE_AA)
        #cv2.putText(frame, str_right, (10, 40), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 0, 255), 3, cv2.LINE_AA)

        #cv2.imshow('Frame', frame)
        ret, jpeg = cv2.imencode('.jpg', frame)
        return jpeg.tobytes()
        # cv2.imshow('Morph closing', mask)

if __name__ == '__main__':
    cam = Cam()