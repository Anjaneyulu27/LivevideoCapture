import numpy as np
import cv2
import FnPersonRBedit
import time
from picamera.array import PiRGBArray
from picamera import PiCamera
import math

# screen dimension

#width = 800   #1280  #1024  #800  #640
#height = 600   #960   #768   #600  #480
width = 800
height= 600

# dividing screen to get x-coordinates of red and blue line
right = int(6.5*(width/10))
left = int(3.5*(width/10))

# extreme lines x-coordinates
left_limit = int(2*(width/10))
right_limit = int(8*(width/10))


# threshold value to detect an object   
areaTH = int(width*height/100)

# count variables
cnt_left = 0
cnt_right = 0

persons = []
max_p_age = 5
pid = 1

# morphology
fgbg = cv2.createBackgroundSubtractorMOG2(detectShadows = True)
kernelOp = np.ones((3,3),np.uint8)
kernelCl = np.ones((11,11),np.uint8)

# camera opening
cap = PiCamera()
cap.resolution = (width, height)
cap.framerate = 15
cap.vflip = True # flipping video vertically
#cap.hflip = True # flipping video horizontally
rawCapture = PiRGBArray(cap)

time.sleep(0.1)

def imageProcessing(frame):
    # Applying background subtraction
    fgmask = fgbg.apply(frame)
    ret,imBin = cv2.threshold(fgmask,200,255,cv2.THRESH_BINARY)

    # Opening (erode->dilate) 
    mask = cv2.morphologyEx(imBin, cv2.MORPH_OPEN, kernelOp)
        
    # Closing (dilate -> erode) 
    mask2 = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernelCl)

    return mask2


def detectMovingObject(cnt,frame):

    # draw rectangle bounding obj
    x,y,w,h = cv2.boundingRect(cnt) 
    cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255,0),2)

    # Finding centroid of the contour
    M = cv2.moments(cnt)    
    cx = int(M['m10']/M['m00'])
    cy = int(M['m01']/M['m00'])
    cv2.circle(frame,(cx,cy), 5, (0,0,255), -1)
    return cx,cy,w,h


def directionCheck(person,cnt):
    # if direction right set cnt
    if person.going_RIGHT_blue(left,right) == True:
        print("going right")
    if person.going_LEFT_red(left,right) == True:
        print("going left")    
    if person.going_RIGHT_Extreme(right) == True:
        cnt = 1
    # if direction left reset cnt
    elif person.going_LEFT_Extreme(left) == True:
        cnt = 0
    return cnt

def checkInActiveRegion(cx,cy,person):
    if person.getState() == '1':
        if person.getDir() == 'left' and cx > left_limit:
            person.setDone()
        elif person.getDir() == 'right' and cx < right_limit:
            person.setDone()
    if cx < left_limit or cx > right_limit:
        # if obj outside active region remove person from the persons list
        index = persons.index(person)
        persons.pop(index)
        del person     # free allocated memory

def calcCoordinates(cx,cy,w,h,person,new):
    cnt = 2 # initialising cnt to 2
    if abs(cx-person.getX()) <= w and abs(cy-person.getY()) <= h: # if the dist btw prev & currnt pt is less than width & height of current person then it is the same person
        new = False # false => initialising it as not a new person        
        person.updateCoords(cx,cy)   # update coordinates in the objct and resets age
        cnt = directionCheck(person,cnt)
    checkInActiveRegion(cx,cy,person)
    return new,cnt

def drawTrackPath(cx,frame,person):
    if len(person.getTracks()) >= 2 and cx in range(left_limit,right_limit):
        pts = np.array(person.getTracks(), np.int32)
        pts = pts.reshape((-1,1,2))
        #frame = cv2.polylines(frame,[pts],False,person.getRGB())
    cv2.putText(frame, str(person.getId()),(person.getX(),person.getY()),cv2.FONT_HERSHEY_SIMPLEX,0.3,person.getRGB(),1,cv2.LINE_AA)


def displayframe(cnt_left,cnt_right,frame):
    str_left = 'IN: '+ str(cnt_left)
    str_right = 'OUT: '+ str(cnt_right)
    
    cv2.line(frame, (left, 0), (left, height), (255, 0, 0), 3) #left blue line
    cv2.line(frame, (right, 0), (right, height), (0, 0, 255), 3) #right red line
    #cv2.line(frame, (left_limit, 0), (left_limit, height), (255, 255, 255), 1) # extreme end left line
    #cv2.line(frame, (right_limit, 0), (right_limit, height), (255, 255, 255), 1) #extreme end right line

    # displaying count on the screen
    cv2.putText(frame, str_left ,(10,90),cv2.FONT_HERSHEY_SIMPLEX,1.5,(255,0,0),3,cv2.LINE_AA) 
    cv2.putText(frame, str_right ,(10,40),cv2.FONT_HERSHEY_SIMPLEX,1.5,(0,0,255),3,cv2.LINE_AA)
        
    cv2.imshow('Frame',frame)
    #cv2.imshow('Morph closing', mask)



########-------- MAIN FUNCTION -------##########
    
for image in cap.capture_continuous(rawCapture, format="bgr", use_video_port=True):
    frame = image.array

    for person in persons:
        person.age_one() # age every person one frame

    try: 
        mask = imageProcessing(frame)
    except:
        print('EOF')
        print('Right:',cnt_right)
        print('Left:',cnt_left)
        break
    
    # RETR_EXTERNAL returns only extreme outer flags. All child contours are left behind.
    _, contours0, hierarchy = cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
    for cnt in contours0:
        area = cv2.contourArea(cnt)
        if area > areaTH:
            cx,cy,w,h = detectMovingObject(cnt,frame)
            new = True  # initialising obj identified is a new person
            if cx in range(left_limit,right_limit):
                for person in persons:
                    new,cnt = calcCoordinates(cx,cy,w,h,person,new)
                    if cnt == 0:
                        cnt_left += 1
                        print("in/left count: ", cnt_left)
                    elif cnt == 1:
                        cnt_right += 1
                        print("out/right count: ", cnt_right)
                if new == True:
                    print("new")
                    p = FnPersonRBedit.MyPerson(pid,cx,cy, max_p_age)
                    persons.append(p)
                    pid += 1 
    
    for person in persons:
        drawTrackPath(cx,frame,person)

    displayframe(cnt_left,cnt_right,frame)

    rawCapture.truncate(0)
    
    k = cv2.waitKey(30) & 0xff
    if k == 27:
        break

cv2.destroyAllWindows()
